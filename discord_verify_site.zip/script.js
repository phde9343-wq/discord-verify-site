document.getElementById("verified").onclick=()=>alert("บัญชีได้รับการยืนยันแล้ว");
document.getElementById("discord").onclick=()=>location.href="https://discord.com/";